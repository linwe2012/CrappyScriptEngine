#ifndef _WHO_CARES_H_
#define _WHO_CARES_H_
#include "checks.h"
// #include "platforms.h"
#include "console.h"

#endif // !_WHO_CARES_H
