#include "factory.h"

Templates *Factory::templates_ = nullptr;
ExecutableAttribute::ExecutorType Factory::dummy_function_;