#ifndef _PRETY_PRINT_H_
#define _PRETY_PRINT_H_

class PrettyPrint {

};

#endif // !_PRETY_PRINT_H_
